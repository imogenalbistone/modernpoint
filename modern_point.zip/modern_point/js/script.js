document.addEventListener('DOMContentLoaded', () => {
    // Form handling
    const vintageForm = document.querySelector('.vintage-form');
    if (vintageForm) {
        vintageForm.addEventListener('submit', (e) => {
            e.preventDefault();
            alert('Your letter has been sent. The Modern Point studio will respond shortly.');
            vintageForm.reset();
        });
    }

    // Current page highlighting
    const currentPage = window.location.pathname.split("/").pop();
    const scrollTabs = document.querySelectorAll('.scroll-tab');
    
    scrollTabs.forEach(tab => {
        const href = tab.getAttribute('href');
        if (href === currentPage || (currentPage === "" && href === "index.html")) {
            tab.classList.add('active');
        } else {
            tab.classList.remove('active');
        }
    });
});
